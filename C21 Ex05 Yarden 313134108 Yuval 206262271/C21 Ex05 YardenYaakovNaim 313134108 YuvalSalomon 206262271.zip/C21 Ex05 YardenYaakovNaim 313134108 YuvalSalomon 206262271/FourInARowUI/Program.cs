﻿using FourInARowLogic;

namespace FourInARowUI
{
    public static class Program
    {
        public static void Main()
        {
            GameSettingsForm gameSettings = new GameSettingsForm();
            gameSettings.ShowDialog();
        }
    }
}
